'use client';

import { useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Header from '../../components/Header';
import BottomNav from '../../components/BottomNav';
import Link from 'next/link';

function ItemSearchContent() {
  const searchParams = useSearchParams();
  const filter = searchParams.get('filter');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedItem, setSelectedItem] = useState(null);

  const items = [
    {
      id: 1,
      name: 'Coffee Pot',
      location: '1F1C03',
      trolley: 'Trolley 1/1',
      galley: 'Forward Galley',
      category: 'Beverage Equipment',
      common: true
    },
    {
      id: 2,
      name: 'Wine Glasses',
      location: '1F2C05',
      trolley: 'Trolley 2/3',
      galley: 'Forward Galley',
      category: 'Glassware',
      common: true
    },
    {
      id: 3,
      name: 'Champagne Flutes',
      location: '2A1C02',
      trolley: 'Trolley 1/2',
      galley: 'Aft Galley',
      category: 'Glassware',
      common: false
    },
    {
      id: 4,
      name: 'Tea Service Set',
      location: '1F1C04',
      trolley: 'Trolley 1/1',
      galley: 'Forward Galley',
      category: 'Service Equipment',
      common: true
    },
    {
      id: 5,
      name: 'Ice Bucket',
      location: '2A2C01',
      trolley: 'Trolley 2/2',
      galley: 'Aft Galley',
      category: 'Service Equipment',
      common: false
    }
  ];

  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filter === 'common' ? item.common : true;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="pt-16 pb-20 px-4">
        {/* Search Bar */}
        <div className="bg-white rounded-xl p-4 mb-6 shadow-sm">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <i className="ri-search-line text-gray-400"></i>
            </div>
            <input
              type="text"
              placeholder="Search items..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          {filter === 'common' && (
            <div className="mt-3 flex items-center text-sm text-blue-600">
              <i className="ri-star-fill mr-2"></i>
              Showing common items only
            </div>
          )}
        </div>

        {/* Items List */}
        <div className="space-y-3">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-xl p-4 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => setSelectedItem(item)}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h3 className="font-semibold text-gray-900">{item.name}</h3>
                    {item.common && (
                      <div className="w-4 h-4 flex items-center justify-center">
                        <i className="ri-star-fill text-orange-500 text-sm"></i>
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mb-1">{item.category}</p>
                  <div className="flex items-center space-x-4 text-sm">
                    <span className="text-blue-600 font-medium">{item.location}</span>
                    <span className="text-gray-500">{item.trolley}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Link
                    href={`/galley?item=${item.id}`}
                    className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center"
                  >
                    <i className="ri-map-pin-line text-blue-600 text-sm"></i>
                  </Link>
                  <i className="ri-arrow-right-s-line text-gray-400"></i>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
              <i className="ri-search-line text-gray-400 text-2xl"></i>
            </div>
            <p className="text-gray-500">No items found</p>
          </div>
        )}
      </div>

      {/* Item Detail Modal */}
      {selectedItem && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="bg-white w-full rounded-t-2xl p-6 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">{selectedItem.name}</h2>
              <button
                onClick={() => setSelectedItem(null)}
                className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
              >
                <i className="ri-close-line text-gray-600"></i>
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-gray-900 mb-2">Location Details</h3>
                <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Position Code:</span>
                    <span className="font-medium">{selectedItem.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Trolley:</span>
                    <span className="font-medium">{selectedItem.trolley}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Galley:</span>
                    <span className="font-medium">{selectedItem.galley}</span>
                  </div>
                </div>
              </div>

              <div className="flex space-x-3">
                <Link
                  href={`/galley?item=${selectedItem.id}`}
                  className="flex-1 bg-blue-600 text-white py-3 rounded-lg text-center font-medium !rounded-button"
                  onClick={() => setSelectedItem(null)}
                >
                  View on Map
                </Link>
                <Link
                  href="/issues"
                  className="px-6 py-3 border border-orange-200 bg-orange-50 text-orange-700 rounded-lg font-medium !rounded-button hover:bg-orange-100 transition-colors"
                  onClick={() => setSelectedItem(null)}
                >
                  Report Issue
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}

export default function ItemsPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <i className="ri-loader-4-line text-2xl text-blue-600 animate-spin mb-2"></i>
          <p className="text-gray-600">Loading items...</p>
        </div>
      </div>
    }>
      <ItemSearchContent />
    </Suspense>
  );
}
